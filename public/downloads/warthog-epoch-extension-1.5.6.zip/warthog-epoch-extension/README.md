# Warthog Epoch Tracker v1.1

Extensión para Brave/Chrome que muestra:

### Pestaña Epoch
- Barra de progreso del epoch actual (8640 bloques)
- Dificultad anterior / actual / próxima estimada
- Altura de bloque y **hashrate de red**
- Ventana independiente que puedes **mantener abierta y mover** por el navegador

### Pestaña Calculadora
- Introduce tu **Janusscore** (H/s)
- Estima WART por día / semana / mes según el hashrate actual de la red

## Instalación

1. Descarga y descomprime el archivo.
2. En Brave ve a `brave://extensions/`
3. Activa **Modo desarrollador**
4. **Cargar extensión sin empaquetar** → selecciona la carpeta
5. Haz clic en el icono de la extensión para abrir la ventana

## Notas
- La ventana se abre como popup independiente (se puede mover y dejar abierta).
- Si el hashrate no aparece en `/chain/head`, intenta obtenerlo del endpoint `/chain/hashrate/100`.
- La calculadora usa el hashrate de red actual + recompensa de 1.5 WART por bloque.

Hecho para la comunidad Warthog 🐗
