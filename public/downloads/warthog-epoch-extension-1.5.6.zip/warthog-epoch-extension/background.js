// Abre o enfoca la ventana popup al hacer clic en el icono
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("popup.html");

  // Buscar si ya hay una ventana con nuestra URL
  const windows = await chrome.windows.getAll({ populate: true, windowTypes: ["popup"] });
  for (const win of windows) {
    if (win.tabs && win.tabs.some(tab => tab.url && tab.url.startsWith(url))) {
      // Ya existe: ponerle foco
      await chrome.windows.update(win.id, { focused: true });
      return;
    }
  }

  // No existe: crear una nueva
  chrome.windows.create({
    url: "popup.html",
    type: "popup",
    width: 400,
    height: 680,
    focused: true
  });
});
