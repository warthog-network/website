const EPOCH_BLOCKS = 8640;
const TARGET_BLOCK_TIME = 20; // segundos
const DIFF_CAP = 2;
const BLOCKS_PER_DAY = Math.round(86400 / TARGET_BLOCK_TIME); // ~4320
const REWARD = 1.5;

const NODES = [
  "https://mainnet.wartnode.com",
  "https://warthognode.duckdns.org",
  "http://65.87.7.86:3001",
  "http://217.182.64.43:3001"
];

let currentNetHashrate = 0;
let currentNode = "";

const TRANSLATIONS = {
  es: {
    tab_epoch: "Epoch",
    tab_calc: "Calculadora",
    loading: "Cargando...",
    progress_label: "Progreso del epoch actual",
    blocks: "bloques",
    remaining_time: "Termina en",
    prev_diff: "Dificultad anterior",
    curr_diff: "Dificultad actual",
    next_diff: "Próxima estimada",
    height: "Altura",
    price: "Precio",
    net_hashrate: "Hashrate red",
    node: "Nodo",
    refresh: "Actualizar",
    epoch_note: "Epoch = 8640 bloques (~2 días)",
    your_janus: "Tu Janusscore (GH/s)",
    janus_placeholder: "Ej: 0.05",
    per_day: "Por día",
    per_week: "Por semana",
    per_month: "Por mes",
    reward: "Recompensa",
    block: "bloque",
    blocks_day: "Bloques/día",
    calculate: "Calcular",
    calc_note: "Estimación basada en hashrate actual de la red",
    auto_refresh: "Auto-actualizar",
    auto_off: "Desactivado",
    updated: "Actualizado",
    connecting: "Conectando...",
    error: "Error"
  },
  en: {
    tab_epoch: "Epoch",
    tab_calc: "Calculator",
    loading: "Loading...",
    progress_label: "Current epoch progress",
    blocks: "blocks",
    remaining: "remaining",
    remaining_time: "Ends in",
    prev_diff: "Previous difficulty",
    curr_diff: "Current difficulty",
    next_diff: "Estimated next",
    height: "Height",
    price: "Price",
    net_hashrate: "Network hashrate",
    node: "Node",
    refresh: "Refresh",
    epoch_note: "Epoch = 8640 blocks (~2 days)",
    your_janus: "Your Janusscore (GH/s)",
    janus_placeholder: "e.g. 0.05",
    per_day: "Per day",
    per_week: "Per week",
    per_month: "Per month",
    reward: "Reward",
    block: "block",
    blocks_day: "Blocks/day",
    calculate: "Calculate",
    calc_note: "Estimate based on current network hashrate",
    auto_refresh: "Auto-refresh",
    auto_off: "Off",
    updated: "Updated",
    connecting: "Connecting...",
    error: "Error"
  }
};

let currentLang = "en";

function t(key) {
  return TRANSLATIONS[currentLang]?.[key] || TRANSLATIONS.es[key] || key;
}

function applyLanguage() {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    if (el.id === "status") return; // no sobrescribir el estado dinámico
    const key = el.dataset.i18n;
    el.textContent = t(key);
  });

  // Placeholders
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    el.placeholder = t(key);
  });

  document.documentElement.lang = currentLang;
  document.getElementById("lang-select").value = currentLang;
}

async function loadLanguage() {
  try {
    const stored = await chrome.storage.local.get("lang");
    if (stored.lang && TRANSLATIONS[stored.lang]) {
      currentLang = stored.lang;
    }
  } catch (e) {}
  applyLanguage();
}

async function setLanguage(lang) {
  if (!TRANSLATIONS[lang]) return;
  currentLang = lang;
  applyLanguage();
  try {
    await chrome.storage.local.set({ lang });
  } catch (e) {}
}

document.getElementById("lang-select").addEventListener("change", (e) => {
  setLanguage(e.target.value);
});

loadLanguage();

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.code !== 0) throw new Error("API error");
  return data.data;
}

async function tryNodes(path) {
  for (const node of NODES) {
    try {
      const data = await fetchJSON(`${node}${path}`);
      return { data, node };
    } catch (e) {
      console.warn(`Failed ${node}:`, e.message);
    }
  }
  throw new Error("No se pudo conectar a ningún nodo público");
}

function toNumber(val) {
  if (typeof val === "number" && !isNaN(val)) return val;
  if (typeof val === "string") {
    const n = parseFloat(val);
    if (!isNaN(n)) return n;
  }
  if (val && typeof val === "object") {
    // Algunos endpoints devuelven {hashrate: X} o similar
    if (typeof val.hashrate === "number") return val.hashrate;
    if (typeof val.value === "number") return val.value;
  }
  return 0;
}

function formatDiff(d) {
  d = toNumber(d);
  if (d <= 0) return "—";
  if (d >= 1e12) return (d / 1e12).toFixed(2) + " T";
  if (d >= 1e9) return (d / 1e9).toFixed(2) + " G";
  if (d >= 1e6) return (d / 1e6).toFixed(2) + " M";
  return d.toFixed(0);
}

function formatHashrate(h) {
  h = toNumber(h);
  if (h <= 0) return "—";
  if (h >= 1e12) return (h / 1e12).toFixed(2) + " TH/s";
  if (h >= 1e9) return (h / 1e9).toFixed(2) + " GH/s";
  if (h >= 1e6) return (h / 1e6).toFixed(2) + " MH/s";
  if (h >= 1e3) return (h / 1e3).toFixed(1) + " kH/s";
  return h.toFixed(0) + " H/s";
}

function formatWART(n) {
  if (n === null || isNaN(n)) return "—";
  if (n >= 1000) return n.toFixed(1);
  if (n >= 10) return n.toFixed(2);
  return n.toFixed(3);
}

let currentPrice = 0;

async function loadPrice() {
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=warthog&vs_currencies=usd");
    const data = await res.json();
    currentPrice = data.warthog?.usd || 0;
    const el = document.getElementById("price-usd");
    const calcEl = document.getElementById("calc-price");
    const text = currentPrice > 0 ? "$" + currentPrice.toFixed(5) : "—";
    if (el) el.textContent = text;
    if (calcEl) calcEl.textContent = text;
  } catch (e) {
    console.warn("Price fetch failed", e);
    const el = document.getElementById("price-usd");
    if (el) el.textContent = "—";
  }
}

function formatTimeLeft(seconds) {
  if (seconds <= 0) return "—";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return h + "h " + m + "m";
  return m + "m";
}

async function loadData() {
  const statusEl = document.getElementById("status");
  statusEl.textContent = t("connecting");
  statusEl.className = "status";

  try {
    const { data: head, node } = await tryNodes("/chain/head");
    currentNode = node;
    const height = head.height;
    const currDiff = head.difficulty;

    // Intentar obtener hashrate de forma fiable
    let hashrate = head.hashrate || 0;
    if (!hashrate || hashrate <= 0) {
      try {
        const hrData = await fetchJSON(`${node}/chain/hashrate/100`);
        hashrate = hrData.hashrate || hrData.lastNBlocksEstimate || hrData || 0;
      } catch (e) {
        console.warn("Hashrate endpoint falló", e);
      }
    }
    currentNetHashrate = toNumber(hashrate);

    const epochStart = Math.floor(height / EPOCH_BLOCKS) * EPOCH_BLOCKS;
    const blocksDone = height - epochStart;
    const blocksLeft = EPOCH_BLOCKS - blocksDone;
    const progress = Math.min(100, (blocksDone / EPOCH_BLOCKS) * 100);

    // Dificultad anterior
    let prevDiff = null;
    if (epochStart > 0) {
      try {
        const prevBlock = await fetchJSON(`${node}/chain/block/${epochStart - 1}/header`);
        prevDiff = prevBlock.header.difficulty;
      } catch (e) {}
    }

    // Estimación próxima dificultad
    let nextDiff = currDiff;
    try {
      const startBlock = await fetchJSON(`${node}/chain/block/${epochStart}/header`);
      const startTime = startBlock.header.timestamp;
      const now = Math.floor(Date.now() / 1000);
      const elapsed = Math.max(1, now - startTime);
      const expected = blocksDone * TARGET_BLOCK_TIME;
      if (expected > 0 && blocksDone > 50) {
        let ratio = expected / elapsed;
        ratio = Math.max(1 / DIFF_CAP, Math.min(DIFF_CAP, ratio));
        nextDiff = currDiff * ratio;
      }
    } catch (e) {}

    // UI Epoch
    document.getElementById("progress-fill").style.width = progress.toFixed(1) + "%";
    document.getElementById("progress-text").textContent = progress.toFixed(1) + "%";
    document.getElementById("blocks-done").textContent = blocksDone.toLocaleString();
    document.getElementById("blocks-left").textContent = blocksLeft.toLocaleString();

    // Cuenta atrás estimada usando dificultad / hashrate
    let blockTime = TARGET_BLOCK_TIME;
    if (currentNetHashrate > 0 && currDiff > 0) {
      blockTime = currDiff / currentNetHashrate;
      // Limitar a un rango razonable por si los datos vienen raros
      blockTime = Math.max(5, Math.min(60, blockTime));
    }
    const timeLeft = blocksLeft * blockTime;
    document.getElementById("countdown").textContent = formatTimeLeft(timeLeft);
    document.getElementById("prev-diff").textContent = formatDiff(prevDiff);
    document.getElementById("curr-diff").textContent = formatDiff(currDiff);
    document.getElementById("next-diff").textContent = formatDiff(nextDiff);
    document.getElementById("height").textContent = height.toLocaleString();
    document.getElementById("hashrate").textContent = formatHashrate(hashrate);
    document.getElementById("node").textContent = node.replace(/^https?:\/\//, "");

    // Actualizar también la calculadora
    document.getElementById("calc-nethash").textContent = formatHashrate(hashrate);

    // Precio
    await loadPrice();

    statusEl.textContent = t("updated");
    statusEl.className = "status";
  } catch (err) {
    statusEl.textContent = t("error") + ": " + err.message;
    statusEl.className = "status error";
  }
}

function calculateEarnings() {
  const input = document.getElementById("user-hr");
  const userGHs = parseFloat(input.value);
  if (!userGHs || userGHs <= 0 || !currentNetHashrate || currentNetHashrate <= 0) {
    document.getElementById("wart-day").textContent = "—";
    document.getElementById("wart-week").textContent = "—";
    document.getElementById("wart-month").textContent = "—";
    return;
  }

  const userHR = userGHs * 1e9; // convertir GH/s a H/s
  const share = userHR / currentNetHashrate;
  const daily = share * BLOCKS_PER_DAY * REWARD;
  const weekly = daily * 7;
  const monthly = daily * 30;

  document.getElementById("wart-day").textContent = formatWART(daily) + " WART";
  document.getElementById("wart-week").textContent = formatWART(weekly) + " WART";
  document.getElementById("wart-month").textContent = formatWART(monthly) + " WART";

  // USD
  if (currentPrice > 0) {
    document.getElementById("usd-day").textContent = "≈ $" + (daily * currentPrice).toFixed(2);
    document.getElementById("usd-week").textContent = "≈ $" + (weekly * currentPrice).toFixed(2);
    document.getElementById("usd-month").textContent = "≈ $" + (monthly * currentPrice).toFixed(2);
  } else {
    document.getElementById("usd-day").textContent = "";
    document.getElementById("usd-week").textContent = "";
    document.getElementById("usd-month").textContent = "";
  }
}

// Tabs
document.querySelectorAll(".tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

let autoInterval = null;

function setAutoRefresh(ms) {
  if (autoInterval) {
    clearInterval(autoInterval);
    autoInterval = null;
  }
  if (ms > 0) {
    autoInterval = setInterval(loadData, ms);
  }
  chrome.storage.local.set({ autoRefresh: ms });
}

document.getElementById("auto-select").addEventListener("change", (e) => {
  setAutoRefresh(parseInt(e.target.value, 10) || 0);
});

// Cargar preferencia de auto-refresh
chrome.storage.local.get("autoRefresh").then(stored => {
  const ms = stored.autoRefresh || 0;
  document.getElementById("auto-select").value = String(ms);
  setAutoRefresh(ms);
});

document.getElementById("refresh").addEventListener("click", loadData);
document.getElementById("calc-btn").addEventListener("click", calculateEarnings);
document.getElementById("user-hr").addEventListener("input", calculateEarnings);

loadData();
